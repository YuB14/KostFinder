import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final card = isDark ? AppColors.cardDark : AppColors.cardLight;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;
    final textColor = isDark ? AppColors.textDark : AppColors.textLight;
    final bg2 = isDark ? AppColors.bg2Dark : AppColors.bg2Light;

    return Scaffold(
      appBar: _buildTopbar(context, isDark, card, border, muted, textColor),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          // ── Welcome header ─────────────────────────────────────
          PageHeader(
            title: 'Selamat Datang, ',
            italic: 'Aini',
            subtitle: 'Ringkasan aktivitas platform KostFinder hari ini. 👋',
          ),
          const SizedBox(height: 20),

          // ── Stat cards 2x2 ────────────────────────────────────
          GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.3,
            children: const [
              StatCard(icon: '🏘️', value: '2.431', label: 'Total Kost', change: '↑ 3.2% bulan ini', changeUp: true, accentColor: AppColors.coral, accentBg: AppColors.coralBg),
              StatCard(icon: '👥', value: '18.432', label: 'Total Pengguna', change: '↑ 8.1% bulan ini', changeUp: true, accentColor: AppColors.teal, accentBg: AppColors.tealBg),
              StatCard(icon: '⭐', value: '9.312', label: 'Total Ulasan', change: '↑ 5.4% bulan ini', changeUp: true, accentColor: AppColors.yellow, accentBg: AppColors.yellowBg),
              StatCard(icon: '❤️', value: '43.210', label: 'Total Favorit', change: '↑ 12.7% bulan ini', changeUp: true, accentColor: AppColors.blue, accentBg: AppColors.blueBg),
            ],
          ),
          const SizedBox(height: 24),

          // ── Kost Terpopuler ───────────────────────────────────
          Row(children: [
            Expanded(child: Text('Kost Terpopuler', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textColor))),
            TextButton(onPressed: () {}, child: const Text('Lihat semua', style: TextStyle(color: AppColors.coral, fontSize: 12, fontWeight: FontWeight.w600))),
          ]),
          const SizedBox(height: 12),

          ..._popularKosts.map((k) => Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: _PopularKostRow(kost: k, isDark: isDark, card: card, border: border, muted: muted, textColor: textColor),
          )),

          const SizedBox(height: 24),

          // ── Aktivitas Terbaru ─────────────────────────────────
          Text('Aktivitas Terbaru', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textColor)),
          const SizedBox(height: 12),

          Container(
            decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border)),
            child: Column(
              children: _activities.asMap().entries.map((e) {
                final i = e.key; final a = e.value;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    border: i < _activities.length - 1 ? Border(bottom: BorderSide(color: border)) : null,
                  ),
                  child: Row(children: [
                    Container(width: 36, height: 36, decoration: BoxDecoration(color: a.bgColor, borderRadius: BorderRadius.circular(10)),
                      child: Center(child: Text(a.icon, style: const TextStyle(fontSize: 16)))),
                    const SizedBox(width: 12),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(a.title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: textColor)),
                      Text(a.sub, style: TextStyle(fontSize: 11, color: muted)),
                    ])),
                    Text(a.time, style: TextStyle(fontSize: 11, color: muted)),
                  ]),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildTopbar(BuildContext context, bool isDark, Color card, Color border, Color muted, Color textColor) {
    return PreferredSize(
      preferredSize: const Size.fromHeight(64),
      child: Container(
        color: card,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SafeArea(
          child: Row(
            children: [
              Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColors.coral, AppColors.coral2]),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [BoxShadow(color: AppColors.coral.withOpacity(0.28), blurRadius: 8)],
                ),
                child: const Center(child: Text('🏠', style: TextStyle(fontSize: 16))),
              ),
              const SizedBox(width: 8),
              RichText(
                text: TextSpan(
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: textColor),
                  children: const [
                    TextSpan(text: 'Kost'),
                    TextSpan(text: 'Finder', style: TextStyle(color: AppColors.coral)),
                  ],
                ),
              ),
              const Spacer(),
              // Search icon
              _iconBtn('🔍', border, card),
              const SizedBox(width: 8),
              // Notif icon
              Stack(clipBehavior: Clip.none, children: [
                _iconBtn('🔔', border, card),
                Positioned(top: 4, right: 4, child: Container(width: 8, height: 8,
                  decoration: BoxDecoration(color: AppColors.coral, shape: BoxShape.circle,
                    border: Border.all(color: card, width: 1.5)))),
              ]),
              const SizedBox(width: 8),
              // Avatar
              Container(
                width: 34, height: 34,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [AppColors.coral, AppColors.coral2]),
                ),
                child: const Center(child: Text('AR', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white))),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _iconBtn(String icon, Color border, Color card) {
    return Container(
      width: 36, height: 36,
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(10), border: Border.all(color: border, width: 1.5)),
      child: Center(child: Text(icon, style: const TextStyle(fontSize: 16))),
    );
  }
}

class _PopularKostData {
  final String emoji, name, location, price, rating, reviews, badgeText;
  final Color badgeColor, badgeBg;
  const _PopularKostData({required this.emoji, required this.name, required this.location, required this.price, required this.rating, required this.reviews, required this.badgeText, required this.badgeColor, required this.badgeBg});
}

final _popularKosts = [
  _PopularKostData(emoji: '🏡', name: 'Kost Griya Asri', location: 'Sumbersari, Jember', price: 'Rp 750.000/bln', rating: '4.6', reviews: '38', badgeText: 'Populer', badgeColor: AppColors.teal, badgeBg: AppColors.tealBg),
  _PopularKostData(emoji: '🏢', name: 'Kost Residence 88', location: 'Patrang, Jember', price: 'Rp 1.500.000/bln', rating: '4.9', reviews: '61', badgeText: 'Premium', badgeColor: AppColors.yellow, badgeBg: AppColors.yellowBg),
  _PopularKostData(emoji: '🏰', name: 'Kost Villa Elok', location: 'Mangli, Jember', price: 'Rp 2.200.000/bln', rating: '5.0', reviews: '29', badgeText: 'Eksklusif', badgeColor: AppColors.yellow, badgeBg: AppColors.yellowBg),
];

class _ActivityData {
  final String icon, title, sub, time;
  final Color bgColor;
  const _ActivityData({required this.icon, required this.title, required this.sub, required this.time, required this.bgColor});
}

final _activities = [
  _ActivityData(icon: '👤', title: 'Pengguna baru terdaftar', sub: 'Dewi Sartika · dewi@mail.com', time: '2m lalu', bgColor: AppColors.tealBg),
  _ActivityData(icon: '⭐', title: 'Ulasan baru masuk', sub: 'Kost Villa Elok · Dewi Sartika', time: '15m lalu', bgColor: AppColors.yellowBg),
  _ActivityData(icon: '❤️', title: 'Favorit ditambahkan', sub: 'Kost Griya Asri · Budi Santoso', time: '1j lalu', bgColor: AppColors.coralBg),
  _ActivityData(icon: '🏘️', title: 'Kost baru diajukan', sub: 'Kost Bintang Mas · Tegalboto', time: '3j lalu', bgColor: AppColors.blueBg),
];

class _PopularKostRow extends StatelessWidget {
  final _PopularKostData kost;
  final bool isDark;
  final Color card, border, muted, textColor;

  const _PopularKostRow({required this.kost, required this.isDark, required this.card, required this.border, required this.muted, required this.textColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border)),
      child: Row(children: [
        Container(width: 50, height: 50,
          decoration: BoxDecoration(color: isDark ? AppColors.bg2Dark : AppColors.bg2Light, borderRadius: BorderRadius.circular(10)),
          child: Center(child: Text(kost.emoji, style: const TextStyle(fontSize: 24)))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(kost.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textColor)),
          const SizedBox(height: 2),
          Text(kost.location, style: TextStyle(fontSize: 11, color: muted)),
          const SizedBox(height: 4),
          Text(kost.price, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.coral)),
        ])),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: kost.badgeBg, borderRadius: BorderRadius.circular(100)),
            child: Text(kost.badgeText, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: kost.badgeColor)),
          ),
          const SizedBox(height: 6),
          Row(children: [
            const Text('⭐', style: TextStyle(fontSize: 11)),
            const SizedBox(width: 3),
            Text(kost.rating, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textColor)),
            Text(' (${kost.reviews})', style: TextStyle(fontSize: 11, color: muted)),
          ]),
        ]),
      ]),
    );
  }
}
