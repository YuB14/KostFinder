import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class FavoriteScreen extends StatefulWidget {
  const FavoriteScreen({super.key});

  @override
  State<FavoriteScreen> createState() => _FavoriteScreenState();
}

class _FavoriteScreenState extends State<FavoriteScreen> {
  final List<_FavData> _favs = [
    _FavData(emoji: '🌸', name: 'Kost Melati Putih', location: 'Jember Kota, Jember', price: 'Rp 450.000', status: 'Tersedia', statusType: 'green', hearts: '842', isFav: true),
    _FavData(emoji: '🏡', name: 'Kost Griya Asri', location: 'Sumbersari, Jember', price: 'Rp 750.000', status: 'Populer', statusType: 'teal', hearts: '2.341', isFav: true),
    _FavData(emoji: '🏢', name: 'Kost Residence 88', location: 'Patrang, Jember', price: 'Rp 1.500.000', status: 'Premium', statusType: 'yellow', hearts: '1.987', isFav: true),
    _FavData(emoji: '🌿', name: 'Kost Barokah', location: 'Kaliwates, Jember', price: 'Rp 380.000', status: 'Tersedia', statusType: 'green', hearts: '614', isFav: true),
    _FavData(emoji: '⭐', name: 'Kost Bintang Mas', location: 'Tegalboto, Jember', price: 'Rp 950.000', status: 'Baru', statusType: 'teal', hearts: '1.203', isFav: true),
    _FavData(emoji: '🏰', name: 'Kost Villa Elok', location: 'Mangli, Jember', price: 'Rp 2.200.000', status: 'Eksklusif', statusType: 'yellow', hearts: '2.121', isFav: true),
  ];

  void _toggleFav(int i) {
    setState(() => _favs[i] = _favs[i].copyWith(isFav: !_favs[i].isFav));
    final fav = _favs[i];
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(fav.isFav ? '❤️  ${fav.name} ditambahkan ke favorit' : '💔  ${fav.name} dihapus dari favorit'),
      backgroundColor: fav.isFav ? AppColors.coral : AppColors.mutedLight,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;

    return Scaffold(
      appBar: AppBar(title: const Text('Favorit')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageHeader(title: 'Kost ', italic: 'Favorit ❤️', subtitle: 'Daftar kost yang disimpan dan difavoritkan pengguna.'),
          const SizedBox(height: 16),

          // Stat Cards 3-col
          Row(children: [
            Expanded(child: StatCard(icon: '❤️', value: '9.312', label: 'Total Favorit', change: '↑ 5.4%', changeUp: true, accentColor: AppColors.coral, accentBg: AppColors.coralBg)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(icon: '🏆', value: 'Griya Asri', label: 'Paling Difavoritkan', accentColor: AppColors.teal, accentBg: AppColors.tealBg)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(icon: '👤', value: '12', label: 'Avg. per User', accentColor: AppColors.yellow, accentBg: AppColors.yellowBg)),
          ]),
          const SizedBox(height: 20),

          Text('Daftar Kost Favorit', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: isDark ? AppColors.textDark : AppColors.textLight)),
          const SizedBox(height: 12),

          GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 0.78,
            children: _favs.asMap().entries.map((e) => _FavCard(
              data: e.value,
              isDark: isDark,
              onToggle: () => _toggleFav(e.key),
            )).toList(),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _FavCard extends StatelessWidget {
  final _FavData data;
  final bool isDark;
  final VoidCallback onToggle;
  const _FavCard({required this.data, required this.isDark, required this.onToggle});

  @override
  Widget build(BuildContext context) {
    final card = isDark ? AppColors.cardDark : AppColors.cardLight;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;
    final textColor = isDark ? AppColors.textDark : AppColors.textLight;
    final bg2 = isDark ? AppColors.bg2Dark : AppColors.bg2Light;

    return Container(
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
      clipBehavior: Clip.hardEdge,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Image area
        Container(
          height: 88,
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [bg2, isDark ? const Color(0xFF243447) : const Color(0xFFC5D8EE)])),
          child: Stack(children: [
            Center(child: Text(data.emoji, style: const TextStyle(fontSize: 36))),
            Positioned(top: 8, right: 8,
              child: GestureDetector(
                onTap: onToggle,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 32, height: 32,
                  decoration: BoxDecoration(
                    color: data.isFav ? AppColors.coral : Colors.white.withOpacity(0.8),
                    shape: BoxShape.circle,
                    boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 6)],
                  ),
                  child: Center(child: Text(data.isFav ? '❤️' : '🤍', style: const TextStyle(fontSize: 15))),
                ),
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(data.name, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textColor), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            Text('📍 ${data.location}', style: TextStyle(fontSize: 10, color: muted), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            Text(data.price, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.coral)),
            Text('/bulan', style: TextStyle(fontSize: 10, color: muted)),
            const SizedBox(height: 8),
            Row(children: [
              _statusBadge(data.status, data.statusType),
              const Spacer(),
              Text('❤️ ${data.hearts}', style: TextStyle(fontSize: 10, color: muted)),
            ]),
          ]),
        ),
      ]),
    );
  }

  Widget _statusBadge(String text, String type) {
    switch (type) {
      case 'teal': return PillBadge.teal(text);
      case 'yellow': return PillBadge.yellow(text);
      default: return PillBadge.green(text);
    }
  }
}

class _FavData {
  final String emoji, name, location, price, status, statusType, hearts;
  final bool isFav;
  const _FavData({required this.emoji, required this.name, required this.location, required this.price, required this.status, required this.statusType, required this.hearts, required this.isFav});
  _FavData copyWith({bool? isFav}) => _FavData(emoji: emoji, name: name, location: location, price: price, status: status, statusType: statusType, hearts: hearts, isFav: isFav ?? this.isFav);
}
