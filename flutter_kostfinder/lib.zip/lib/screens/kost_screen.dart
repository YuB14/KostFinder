import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class KostScreen extends StatefulWidget {
  const KostScreen({super.key});

  @override
  State<KostScreen> createState() => _KostScreenState();
}

class _KostScreenState extends State<KostScreen> {
  bool _isGrid = true;
  String _search = '';

  final _kosts = const [
    _KostData(emoji: '🌸', name: 'Kost Melati Putih', location: 'Jember Kota, Jember', price: 'Rp 450.000', tier: 'Tersedia', tierType: 'coral', rating: '4.2', reviews: '24', tags: ['WiFi', 'Air Panas', 'Parkir']),
    _KostData(emoji: '🏡', name: 'Kost Griya Asri', location: 'Sumbersari, Jember', price: 'Rp 750.000', tier: 'Populer', tierType: 'teal', rating: '4.6', reviews: '38', tags: ['WiFi', 'AC', 'KM Dalam']),
    _KostData(emoji: '🏢', name: 'Kost Residence 88', location: 'Patrang, Jember', price: 'Rp 1.500.000', tier: 'Premium', tierType: 'yellow', rating: '4.9', reviews: '61', tags: ['WiFi', 'AC', 'Gym']),
    _KostData(emoji: '🏰', name: 'Kost Villa Elok', location: 'Mangli, Jember', price: 'Rp 2.200.000', tier: 'Eksklusif', tierType: 'yellow', rating: '5.0', reviews: '29', tags: ['Kolam', 'AC', 'TV']),
    _KostData(emoji: '🌿', name: 'Kost Barokah', location: 'Kaliwates, Jember', price: 'Rp 380.000', tier: 'Tersedia', tierType: 'coral', rating: '4.1', reviews: '18', tags: ['WiFi', 'Parkir']),
    _KostData(emoji: '⭐', name: 'Kost Bintang Mas', location: 'Tegalboto, Jember', price: 'Rp 950.000', tier: 'Baru', tierType: 'teal', rating: '4.4', reviews: '12', tags: ['WiFi', 'AC', 'Laundry']),
  ];

  List<_KostData> get _filtered => _kosts.where((k) => k.name.toLowerCase().contains(_search.toLowerCase()) || k.location.toLowerCase().contains(_search.toLowerCase())).toList();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final card = isDark ? AppColors.cardDark : AppColors.cardLight;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;
    final textColor = isDark ? AppColors.textDark : AppColors.textLight;
    final bg2 = isDark ? AppColors.bg2Dark : AppColors.bg2Light;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Kost'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none_rounded),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageHeader(title: 'Data ', italic: 'Kost', subtitle: 'Kelola semua listing kost yang terdaftar di platform.'),
          const SizedBox(height: 16),

          // ── Stat Cards ─────────────────────────────────────────
          GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.4,
            children: const [
              StatCard(icon: '🏘️', value: '6', label: 'Total Kost Aktif', accentColor: AppColors.coral, accentBg: AppColors.coralBg),
              StatCard(icon: '✅', value: '5', label: 'Sudah Terverifikasi', accentColor: AppColors.teal, accentBg: AppColors.tealBg),
              StatCard(icon: '⭐', value: '4.87', label: 'Avg. Rating', accentColor: AppColors.yellow, accentBg: AppColors.yellowBg),
              StatCard(icon: '⏳', value: '1', label: 'Menunggu Review', accentColor: AppColors.blue, accentBg: AppColors.blueBg),
            ],
          ),
          const SizedBox(height: 20),

          // ── Toolbar ────────────────────────────────────────────
          Row(children: [
            // Grid / List toggle
            Container(
              decoration: BoxDecoration(color: bg2, borderRadius: BorderRadius.circular(10)),
              child: Row(children: [
                _ViewBtn(icon: Icons.grid_view_rounded, active: _isGrid, onTap: () => setState(() => _isGrid = true)),
                _ViewBtn(icon: Icons.view_list_rounded, active: !_isGrid, onTap: () => setState(() => _isGrid = false)),
              ]),
            ),
            const SizedBox(width: 10),
            Expanded(child: SearchBar2(hint: 'Cari kost...', onChanged: (v) => setState(() => _search = v))),
          ]),
          const SizedBox(height: 16),

          // ── Content ────────────────────────────────────────────
          if (_isGrid)
            GridView.count(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12,
              shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 0.72,
              children: _filtered.map((k) => _KostGridCard(kost: k, isDark: isDark, card: card, border: border, muted: muted, textColor: textColor)).toList(),
            )
          else
            Column(children: _filtered.map((k) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _KostListCard(kost: k, isDark: isDark, card: card, border: border, muted: muted, textColor: textColor),
            )).toList()),

          const SizedBox(height: 20),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showAddDialog(context),
        backgroundColor: AppColors.coral,
        icon: const Text('🏘️', style: TextStyle(fontSize: 18)),
        label: const Text('Tambah Kost', style: TextStyle(fontWeight: FontWeight.w700, color: Colors.white)),
      ),
    );
  }

  void _showAddDialog(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('🏘️  Form tambah kost segera hadir!'),
        backgroundColor: AppColors.coral,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}

// ── View Toggle Button ─────────────────────────────────────────────────────
class _ViewBtn extends StatelessWidget {
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  const _ViewBtn({required this.icon, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(9),
        decoration: BoxDecoration(
          color: active ? (isDark ? AppColors.cardDark : AppColors.cardLight) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          boxShadow: active ? [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 6)] : [],
        ),
        child: Icon(icon, size: 18, color: active ? AppColors.coral : (isDark ? AppColors.mutedDark : AppColors.mutedLight)),
      ),
    );
  }
}

// ── Kost Grid Card ─────────────────────────────────────────────────────────
class _KostGridCard extends StatelessWidget {
  final _KostData kost;
  final bool isDark;
  final Color card, border, muted, textColor;
  const _KostGridCard({required this.kost, required this.isDark, required this.card, required this.border, required this.muted, required this.textColor});

  @override
  Widget build(BuildContext context) {
    final bg2 = isDark ? AppColors.bg2Dark : AppColors.bg2Light;
    final (badgeColor, badgeBg) = _tierColors(kost.tierType);
    return Container(
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)]),
      clipBehavior: Clip.hardEdge,
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Image area
        Container(
          height: 90,
          decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [bg2, isDark ? const Color(0xFF243447) : const Color(0xFFC5D8EE)])),
          child: Stack(children: [
            Center(child: Text(kost.emoji, style: const TextStyle(fontSize: 38))),
            Positioned(top: 8, left: 8, child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: badgeColor, borderRadius: BorderRadius.circular(100)),
              child: Text(kost.tier, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white)),
            )),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(kost.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textColor), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 2),
            Text('📍 ${kost.location}', style: TextStyle(fontSize: 10, color: muted), maxLines: 1, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 6),
            Text(kost.price, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: AppColors.coral)),
            Text('/bulan', style: TextStyle(fontSize: 10, color: muted)),
            const SizedBox(height: 8),
            Wrap(spacing: 4, runSpacing: 4, children: kost.tags.take(3).map((t) => KostTag(t)).toList()),
            const SizedBox(height: 8),
            Row(children: [
              Text('⭐', style: const TextStyle(fontSize: 12)),
              const SizedBox(width: 3),
              Text(kost.rating, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textColor)),
              Text(' (${kost.reviews})', style: TextStyle(fontSize: 10, color: muted)),
              const Spacer(),
              GestureDetector(
                onTap: () {},
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(color: AppColors.coralBg, borderRadius: BorderRadius.circular(8)),
                  child: const Text('Edit', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.coral)),
                ),
              ),
            ]),
          ]),
        ),
      ]),
    );
  }
}

// ── Kost List Card ─────────────────────────────────────────────────────────
class _KostListCard extends StatelessWidget {
  final _KostData kost;
  final bool isDark;
  final Color card, border, muted, textColor;
  const _KostListCard({required this.kost, required this.isDark, required this.card, required this.border, required this.muted, required this.textColor});

  @override
  Widget build(BuildContext context) {
    final bg2 = isDark ? AppColors.bg2Dark : AppColors.bg2Light;
    final (badgeColor, badgeBg) = _tierColors(kost.tierType);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(14), border: Border.all(color: border)),
      child: Row(children: [
        Container(width: 54, height: 54, decoration: BoxDecoration(color: bg2, borderRadius: BorderRadius.circular(10)),
          child: Center(child: Text(kost.emoji, style: const TextStyle(fontSize: 26)))),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(kost.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textColor), maxLines: 1, overflow: TextOverflow.ellipsis),
          Text('📍 ${kost.location}', style: TextStyle(fontSize: 11, color: muted), maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 4),
          Row(children: [
            Text(kost.price, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w800, color: AppColors.coral)),
            Text('/bln', style: TextStyle(fontSize: 10, color: muted)),
            const SizedBox(width: 8),
            Text('⭐ ${kost.rating}', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: textColor)),
          ]),
        ])),
        Column(children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(color: badgeBg, borderRadius: BorderRadius.circular(100)),
            child: Text(kost.tier, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: badgeColor)),
          ),
          const SizedBox(height: 8),
          Row(children: [
            _actionBtn('✏️'),
            const SizedBox(width: 6),
            _actionBtn('🗑️'),
          ]),
        ]),
      ]),
    );
  }

  Widget _actionBtn(String icon) => Container(
    width: 30, height: 30,
    decoration: BoxDecoration(color: isDark ? AppColors.bg2Dark : AppColors.bg2Light, borderRadius: BorderRadius.circular(8)),
    child: Center(child: Text(icon, style: const TextStyle(fontSize: 14))),
  );
}

(Color, Color) _tierColors(String type) {
  switch (type) {
    case 'teal': return (AppColors.teal, AppColors.tealBg);
    case 'yellow': return (AppColors.yellow, AppColors.yellowBg);
    case 'blue': return (AppColors.blue, AppColors.blueBg);
    default: return (AppColors.coral, AppColors.coralBg);
  }
}

class _KostData {
  final String emoji, name, location, price, tier, tierType, rating, reviews;
  final List<String> tags;
  const _KostData({required this.emoji, required this.name, required this.location, required this.price, required this.tier, required this.tierType, required this.rating, required this.reviews, required this.tags});
}
