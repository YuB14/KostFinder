import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class ReviewScreen extends StatelessWidget {
  const ReviewScreen({super.key});

  static const _reviews = [
    _ReviewData(initials: 'AR', name: 'Aini Rahmawati', kost: 'Kost Residence 88', stars: 5, text: 'Kost terbaik! Fasilitas lengkap, pemilik ramah, dan lingkungan sangat bersih. Sangat worth it dengan harganya.', date: '12 Mar 2025', status: 'approved', gradientColors: [AppColors.coral, AppColors.coral2]),
    _ReviewData(initials: 'BS', name: 'Budi Santoso', kost: 'Kost Griya Asri', stars: 4, text: 'Lokasi strategis dekat kampus, WiFi kencang, kamar bersih. Hanya AC terkadang sedikit berisik, tapi overall sangat memuaskan!', date: '5 Mar 2025', status: 'approved', gradientColors: [AppColors.teal, AppColors.teal2]),
    _ReviewData(initials: 'DS', name: 'Dewi Sartika', kost: 'Kost Villa Elok', stars: 5, text: 'Benar-benar seperti hotel! Kolam renang, gym, cleaning service setiap hari. Harga tinggi tapi sepadan banget!', date: '28 Feb 2025', status: 'pending', gradientColors: [AppColors.yellow, Color(0xFFF6C244)]),
    _ReviewData(initials: 'RH', name: 'Rizky Hidayat', kost: 'Kost Barokah', stars: 4, text: 'Kost terjangkau dengan fasilitas yang cukup lengkap. Pemilik kost sangat responsif dan ramah.', date: '20 Feb 2025', status: 'approved', gradientColors: [AppColors.blue, Color(0xFF60A5FA)]),
    _ReviewData(initials: 'NA', name: 'Nur Aini', kost: 'Kost Bintang Mas', stars: 3, text: 'Lokasi bagus tapi kamar agak sempit. WiFi sering gangguan pada jam malam. Harga cukup sesuai.', date: '15 Feb 2025', status: 'rejected', gradientColors: [AppColors.mutedLight, Color(0xFF94A3B8)]),
  ];

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('Ulasan')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageHeader(title: 'Manajemen ', italic: 'Ulasan', subtitle: 'Pantau dan moderasi ulasan pengguna pada seluruh kost.'),
          const SizedBox(height: 16),

          // Stat Cards
          GridView.count(
            crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.4,
            children: const [
              StatCard(icon: '⭐', value: '214', label: 'Total Ulasan', accentColor: AppColors.yellow, accentBg: AppColors.yellowBg),
              StatCard(icon: '✅', value: '198', label: 'Disetujui', accentColor: AppColors.teal, accentBg: AppColors.tealBg),
              StatCard(icon: '⏳', value: '12', label: 'Menunggu', accentColor: AppColors.coral, accentBg: AppColors.coralBg),
              StatCard(icon: '🚫', value: '4', label: 'Ditolak', accentColor: AppColors.blue, accentBg: AppColors.blueBg),
            ],
          ),
          const SizedBox(height: 20),

          Text('Daftar Ulasan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: isDark ? AppColors.textDark : AppColors.textLight)),
          const SizedBox(height: 12),

          ..._reviews.map((r) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _ReviewCard(review: r, isDark: isDark),
          )),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _ReviewCard extends StatelessWidget {
  final _ReviewData review;
  final bool isDark;
  const _ReviewCard({required this.review, required this.isDark});

  @override
  Widget build(BuildContext context) {
    final card = isDark ? AppColors.cardDark : AppColors.cardLight;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;
    final textColor = isDark ? AppColors.textDark : AppColors.textLight;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: card, borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // Header
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: review.gradientColors),
            ),
            child: Center(child: Text(review.initials, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Colors.white))),
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(review.name, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: textColor)),
            Text(review.kost, style: TextStyle(fontSize: 11, color: AppColors.coral, fontWeight: FontWeight.w500)),
          ])),
          // Stars
          Row(children: List.generate(5, (i) => Text(
            i < review.stars ? '★' : '☆',
            style: TextStyle(fontSize: 14, color: i < review.stars ? AppColors.yellow : muted),
          ))),
        ]),
        const SizedBox(height: 10),

        // Review text
        Text(
          '"${review.text}"',
          style: TextStyle(fontSize: 13, color: isDark ? AppColors.text2Dark : AppColors.text2Light, fontStyle: FontStyle.italic, height: 1.5),
        ),
        const SizedBox(height: 10),

        // Footer
        Row(children: [
          Text(review.date, style: TextStyle(fontSize: 11, color: muted)),
          const Spacer(),
          _statusBadge(review.status),
        ]),
      ]),
    );
  }

  Widget _statusBadge(String status) {
    switch (status) {
      case 'approved': return PillBadge.green('✅ Disetujui');
      case 'pending': return PillBadge.yellow('⏳ Menunggu');
      case 'rejected': return const PillBadge(text: '🚫 Ditolak', color: Color(0xFFE53E3E), bgColor: Color(0x1AE53E3E));
      default: return const SizedBox();
    }
  }
}

class _ReviewData {
  final String initials, name, kost, text, date, status;
  final int stars;
  final List<Color> gradientColors;
  const _ReviewData({required this.initials, required this.name, required this.kost, required this.stars, required this.text, required this.date, required this.status, required this.gradientColors});
}
