import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class UserScreen extends StatefulWidget {
  const UserScreen({super.key});

  @override
  State<UserScreen> createState() => _UserScreenState();
}

class _UserScreenState extends State<UserScreen> {
  String _search = '';

  static const _users = [
    _UserData(initials: 'AR', name: 'Aini Rahmawati', email: 'admin@kostfinder.com', role: 'Admin', status: 'active', joined: '12 Jan 2025', favorites: '8', gradients: [AppColors.coral, AppColors.coral2]),
    _UserData(initials: 'BS', name: 'Budi Santoso', email: 'budi@mail.com', role: 'Pengguna', status: 'active', joined: '3 Feb 2025', favorites: '3', gradients: [AppColors.teal, AppColors.teal2]),
    _UserData(initials: 'DS', name: 'Dewi Sartika', email: 'dewi@mail.com', role: 'Pengguna', status: 'inactive', joined: '20 Mar 2025', favorites: '12', gradients: [AppColors.yellow, Color(0xFFF6C244)]),
    _UserData(initials: 'RH', name: 'Rizky Hidayat', email: 'rizky@mail.com', role: 'Pengguna', status: 'active', joined: '5 Apr 2025', favorites: '5', gradients: [AppColors.blue, Color(0xFF60A5FA)]),
    _UserData(initials: 'NA', name: 'Nur Aini', email: 'nur@mail.com', role: 'Pengguna', status: 'inactive', joined: '18 Apr 2025', favorites: '2', gradients: [AppColors.mutedLight, Color(0xFF94A3B8)]),
  ];

  List<_UserData> get _filtered => _users.where((u) =>
    u.name.toLowerCase().contains(_search.toLowerCase()) ||
    u.email.toLowerCase().contains(_search.toLowerCase())).toList();

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final card = isDark ? AppColors.cardDark : AppColors.cardLight;
    final border = isDark ? AppColors.borderDark : AppColors.borderLight;
    final muted = isDark ? AppColors.mutedDark : AppColors.mutedLight;
    final textColor = isDark ? AppColors.textDark : AppColors.textLight;

    return Scaffold(
      appBar: AppBar(title: const Text('Pengguna')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          PageHeader(title: 'Manajemen ', italic: 'Pengguna', subtitle: 'Kelola semua pengguna yang terdaftar di KostFinder.'),
          const SizedBox(height: 16),

          // Stat cards
          Row(children: [
            Expanded(child: StatCard(icon: '👥', value: '18.432', label: 'Total Pengguna', change: '↑ 8.1%', changeUp: true, accentColor: AppColors.teal, accentBg: AppColors.tealBg)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(icon: '🟢', value: '3.241', label: 'Aktif Hari Ini', change: '↑ 2.3%', changeUp: true, accentColor: AppColors.coral, accentBg: AppColors.coralBg)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(icon: '🆕', value: '142', label: 'Daftar Bulan Ini', change: '↑ 15.2%', changeUp: true, accentColor: AppColors.yellow, accentBg: AppColors.yellowBg)),
          ]),
          const SizedBox(height: 20),

          // Table header + search
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: card, borderRadius: const BorderRadius.vertical(top: Radius.circular(14)), border: Border.all(color: border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Text('Daftar Pengguna', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: textColor)),
                const Spacer(),
                OutlinedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.filter_list_rounded, size: 14),
                  label: const Text('Filter'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                    side: BorderSide(color: border),
                    foregroundColor: muted,
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.add_rounded, size: 14, color: Colors.white),
                  label: const Text('Tambah', style: TextStyle(color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                    backgroundColor: AppColors.coral,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                ),
              ]),
              const SizedBox(height: 12),
              SearchBar2(hint: 'Cari pengguna...', onChanged: (v) => setState(() => _search = v)),
            ]),
          ),

          // Table header row
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            color: isDark ? AppColors.bg2Dark : AppColors.bg2Light,
            child: Row(children: [
              Expanded(flex: 3, child: Text('PENGGUNA', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: muted, letterSpacing: 0.7))),
              Expanded(flex: 2, child: Text('STATUS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: muted, letterSpacing: 0.7))),
              Expanded(flex: 2, child: Text('BERGABUNG', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: muted, letterSpacing: 0.7))),
              SizedBox(width: 60, child: Text('AKSI', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: muted, letterSpacing: 0.7), textAlign: TextAlign.center)),
            ]),
          ),

          // User rows
          Container(
            decoration: BoxDecoration(
              color: card,
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(14)),
              border: Border.all(color: border),
            ),
            child: Column(
              children: _filtered.asMap().entries.map((e) {
                final i = e.key; final u = e.value;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    border: i < _filtered.length - 1 ? Border(bottom: BorderSide(color: border)) : null,
                  ),
                  child: Row(children: [
                    Expanded(flex: 3, child: Row(children: [
                      Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: u.gradients),
                        ),
                        child: Center(child: Text(u.initials, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white))),
                      ),
                      const SizedBox(width: 8),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(u.name, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: textColor), maxLines: 1, overflow: TextOverflow.ellipsis),
                        Text(u.role, style: TextStyle(fontSize: 10, color: muted)),
                      ])),
                    ])),
                    Expanded(flex: 2, child: u.status == 'active' ? PillBadge.green('● Aktif') : PillBadge.yellow('● Tidak Aktif')),
                    Expanded(flex: 2, child: Text(u.joined, style: TextStyle(fontSize: 11, color: muted))),
                    SizedBox(width: 60, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      _ActionBtn(icon: '✏️', onTap: () {}),
                      const SizedBox(width: 5),
                      _ActionBtn(icon: '👁️', onTap: () {}),
                    ])),
                  ]),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String icon;
  final VoidCallback onTap;
  const _ActionBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28, height: 28,
        decoration: BoxDecoration(
          color: isDark ? AppColors.bg2Dark : AppColors.bg2Light,
          borderRadius: BorderRadius.circular(7),
        ),
        child: Center(child: Text(icon, style: const TextStyle(fontSize: 13))),
      ),
    );
  }
}

class _UserData {
  final String initials, name, email, role, status, joined, favorites;
  final List<Color> gradients;
  const _UserData({required this.initials, required this.name, required this.email, required this.role, required this.status, required this.joined, required this.favorites, required this.gradients});
}
